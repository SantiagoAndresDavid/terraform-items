from random import randint
import boto3
import json
import pymysql

# Configura la conexión a tu base de datos RDS
TABLE_NAME = "items_data"
endpoint = 'database-1.cns8a4ikg5db.us-west-2.rds.amazonaws.com'
username = 'admin'
password = '123456789pwd'
database_name = 'items'
port = 3306

# Inicializa los clientes de boto3
s3_client = boto3.client('s3')

headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,Access-Control-Request-Headers",
}

def handle(event, context):
    # Verifica que el evento contiene los datos necesarios
    if 'title' not in event or 'body' not in event:
        return {
            "statusCode": 400,
            "headers": headers,
            "body": json.dumps({"error": "Missing 'title' or 'body' in the event"})
        }

    id = str(randint(0, 200))
    title = event["title"]
    body = event["body"]
    file_name = str(title + "-" + id + ".json")
    data = json.dumps({"title": title, "body": body})
    target_file = 'data/' + file_name

    try:
        # Guardar el archivo en S3
        s3_client.put_object(Bucket='items-01', Key=target_file, Body=data)

        # Establecer la conexión a la base de datos
        connection = pymysql.connect(host=endpoint, user=username, password=password, db=database_name, port=port)
        cursor = connection.cursor()

        # Insertar el nuevo registro en la base de datos
        sql = "INSERT INTO {} (id, title, body) VALUES (%s, %s, %s)".format(TABLE_NAME)
        cursor.execute(sql, (id, title, body))

        # Commit para asegurarse de que los cambios se guarden en la base de datos
        connection.commit()
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({
                "id": id,
                "title": title,
                "body": body,
            })
        }
    except pymysql.MySQLError as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "Database error", "message": str(e)})
        }
    except boto3.exceptions.Boto3Error as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "S3 error", "message": str(e)})
        }
    except Exception as e:
        return {
            "statusCode": 400,
            "headers": headers,
            "body": json.dumps({"error": "Request processing error", "message": str(e)})
        }
    finally:
        # Asegurar que la conexión se cierra
        try:
            if connection:
                connection.close()
        except Exception as e:
            return {
                "statusCode": 500,
                "headers": headers,
                "body": json.dumps({"error": "Error closing connection", "message": str(e)})
            }
